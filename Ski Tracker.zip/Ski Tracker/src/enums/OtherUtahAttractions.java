package enums;

public enum OtherUtahAttractions {
SLC_INTERNATIONAL_AIRPORT,
NEUMONT,
U_OF_U,
ZION_NATIONAL_PARK,
BRYCE_CANYON,
MOAB,
}
