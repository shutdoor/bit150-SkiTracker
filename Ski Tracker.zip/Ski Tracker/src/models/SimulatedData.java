package models;
public class SimulatedData {
	private static void estimateNumOfVisitors(double snowDepth) {

	}
}
