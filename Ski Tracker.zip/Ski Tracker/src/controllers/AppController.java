package controllers;

import models.User;

public class AppController {

	public static void run() {
		
	}
	
	private static User createNewUser() {
		return null;
		
	}
	private static void login() {
		
	}
}
