package interfaces;

public interface Customizable {
	public void setNewPosition(int newPositionX, int newPositionY);

}
